
    <section class="hero-section">
        <div class="container">
            <div class="row">
               
         <div class="col-lg-6">
                    <div>
                        <h2></h2>
                        <p></p>
                        <a href="#" ></a>
                    </div>
                </div>
              
            </div>
        </div>
        <div>
            <img src="<?php echo base_url('/') ?>assets/img/reg.jpg"/>
         <!--  <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-google-plus"></i></a>
                <a href="#"><i class="fa fa-pinterest"></i></a> -->
             <!--<div  data-setbg="img/reg.jpg"></div>-->
            <!--<div class="hs-item set-bg" data-setbg="img/hero-slider/2.jpg"></div>
            <div class="hs-item set-bg" data-setbg="img/hero-slider/3.jpg"></div>-->
        </div>
    </section>
   
    <section class="why-section spad">
        <div class="container">
            <div class="text-center mb-5 pb-4">
                <h2>Welcome to Money Bazar <br />

            </div>
          
            <div class="text-center pt-3">
                <div class="text-center">
                    <p>Important note regarding pricing:
                      Online registration will close at Midnight Eastern on Monday, October 12, 2020. The early pricing referenced above will only be valid when online registration is open. Once online registration closes, on-site pricing will take effect.  ALL PRICES ARE USD</p>
                </div>
                <a href="#" class="site-btn sb-big">Apply Now!</a>
            </div>
        </div>
    </section>
    
   