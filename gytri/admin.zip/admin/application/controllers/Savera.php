<?php
// class Savera extends CI_Controller {

//         public function __construct()
//         {
//                 parent::__construct();
//              // $this->data['pageTitle'] = 'Test Title';
//                 // $this->auth();
//                $this->load->model('Number_model');
//         }


//        public function index()
//        {

//         $data['res']=$this->Number_model->get_all();
//         $data['fl']=$this->Number_model->fl();
//         $data['last']=$this->Number_model->getlast_record();
//         // echo '<pre>';
//         // print_r($data['fl']);die;
//         // echo '</pre>';
      
//       	$this->load->view('home',$data);
     
//        }




   

      

      
}